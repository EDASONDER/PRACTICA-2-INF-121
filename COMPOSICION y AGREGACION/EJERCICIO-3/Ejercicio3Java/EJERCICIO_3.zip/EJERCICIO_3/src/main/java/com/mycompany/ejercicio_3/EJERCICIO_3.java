/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_3;

/**
 *
 * @author Usuario
 */
public class EJERCICIO_3 {

    public static void main(String[] args) {
        // a) Crear partes del avión
        Parte motor = new Parte("Motor Turbofan", 1500.5);
        Parte alaDerecha = new Parte("Ala Derecha", 800.0);
        Parte alaIzquierda = new Parte("Ala Izquierda", 800.0);
        Parte trenAterrizaje = new Parte("Tren de Aterrizaje", 1200.75);

        // b) Crear un avión y agregar partes
        Avion avionComercial = new Avion("Boeing 747", "Boeing");
        avionComercial.agregarParte(motor);
        avionComercial.agregarParte(alaDerecha);
        avionComercial.agregarParte(alaIzquierda);
        avionComercial.agregarParte(trenAterrizaje);

        // c) Mostrar información del avión y sus partes
        avionComercial.mostrarAvion();
    }
}
