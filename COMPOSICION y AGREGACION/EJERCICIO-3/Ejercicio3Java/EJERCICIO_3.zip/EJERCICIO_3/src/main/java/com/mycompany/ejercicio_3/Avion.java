/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_3;

/**
 *
 * @author Usuario
 */
import java.util.ArrayList;
import java.util.List;

public class Avion {
    private String modelo;
    private String fabricante;
    private List<Parte> partes; // Composición: Avión "tiene" Partes

    // Constructor
    public Avion(String modelo, String fabricante) {
        this.modelo = modelo;
        this.fabricante = fabricante;
        this.partes = new ArrayList<>(); // Inicializa la lista
    }

    // Método para agregar partes
    public void agregarParte(Parte parte) {
        partes.add(parte);
    }

    // Método para mostrar información del avión y sus partes
    public void mostrarAvion() {
        System.out.println("=== Información del Avión ===");
        System.out.println("Modelo: " + modelo + ", Fabricante: " + fabricante);
        System.out.println("Partes:");

        for (Parte parte : partes) {
            parte.mostrarInfo(); // Llama al método de Parte
        }
    }
}