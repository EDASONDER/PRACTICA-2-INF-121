/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_1;

/**
 *
 * @author Usuario
 */
import java.util.ArrayList;
import java.util.List;

public class Casa {
    private String direccion;
    private List<Habitacion> habitaciones; // Composición: Casa "tiene" Habitaciones

    // Constructor
    public Casa(String direccion) {
        this.direccion = direccion;
        this.habitaciones = new ArrayList<>(); // Inicializa la lista
    }

    // Método para agregar habitaciones
    public void agregarHabitacion(Habitacion habitacion) {
        habitaciones.add(habitacion);
    }

    // Método para mostrar información de la casa y sus habitaciones
    public void mostrarCasa() {
        System.out.println("=== Informacion de la Casa ===");
        System.out.println("Direccion: " + direccion);
        System.out.println("Habitaciones:");

        for (Habitacion habitacion : habitaciones) {
            habitacion.mostrarInfo(); // Llama al método de Habitacion
        }
    }
}