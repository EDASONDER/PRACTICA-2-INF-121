/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_1;

/**
 *
 * @author Usuario
 */
public class Habitacion {
    private String nombre;
    private double tamanio; // en metros cuadrados

    // Constructor
    public Habitacion(String nombre, double tamanio) {
        this.nombre = nombre;
        this.tamanio = tamanio;
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public double getTamanio() {
        return tamanio;
    }

    // Método para mostrar información
    public void mostrarInfo() {
        System.out.println("Habitacion: " + nombre + ", Tamano: " + tamanio + " m²");
    }
}