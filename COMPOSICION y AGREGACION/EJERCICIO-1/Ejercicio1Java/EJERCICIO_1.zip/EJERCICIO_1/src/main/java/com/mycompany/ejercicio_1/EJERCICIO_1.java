/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_1;

/**
 *
 * @author Usuario
 */
public class EJERCICIO_1 {

    public static void main(String[] args) {
        // a) Crear habitaciones
        Habitacion sala = new Habitacion("Sala", 20.5);
        Habitacion cocina = new Habitacion("Cocina", 12.0);
        Habitacion dormitorio = new Habitacion("Dormitorio Principal", 15.75);

        // b) Crear una casa y agregar habitaciones
        Casa miCasa = new Casa("Calle Falsa 123");
        miCasa.agregarHabitacion(sala);
        miCasa.agregarHabitacion(cocina);
        miCasa.agregarHabitacion(dormitorio);

        // c) Mostrar información de la casa y sus habitaciones
        miCasa.mostrarCasa();
    }
}
