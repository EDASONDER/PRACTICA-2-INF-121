/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio1;

/**
 *
 * @author Usuario
 */
public class Vehiculo {
    private String marca;
    private String modelo;
    private int año;
    private double precioBase;

    // Constructor
    public Vehiculo(String marca, String modelo, int año, double precioBase) {
        this.marca = marca;
        this.modelo = modelo;
        this.año = año;
        this.precioBase = precioBase;
    }

    // Getters y Setters
    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getAño() {
        return año;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    // Método para mostrar información básica
    public void mostrarInfo() {
        System.out.println("Marca: " + marca + ", Modelo: " + modelo + 
                         ", Ano: " + año + ", Precio Base: $" + precioBase);
    }
}