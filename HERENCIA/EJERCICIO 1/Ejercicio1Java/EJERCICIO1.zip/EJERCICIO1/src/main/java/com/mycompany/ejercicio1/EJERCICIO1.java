/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio1;

/**
 *
 * @author Usuario
 */

import java.util.ArrayList;
import java.util.List;

public class EJERCICIO1 {

    public static void main(String[] args) {
        // Crear instancias de Coche y Moto
        Coche coche1 = new Coche("Toyota", "Corolla", 2023, 25000, 4, "Gasolina");
        Coche coche2 = new Coche("Ford", "Mustang", 2024, 45000, 2, "Gasolina");
        Moto moto1 = new Moto("Honda", "CBR600", 2022, 12000, 600, "4T");

        // b) Mostrar información de los vehículos
        System.out.println("=== Informacion de Vehiculos ===");
        coche1.mostrarInfo();
        System.out.println("-------------------");
        coche2.mostrarInfo();
        System.out.println("-------------------");
        moto1.mostrarInfo();

        // c) Mostrar coches con más de 4 puertas
        List<Coche> coches = new ArrayList<>();
        coches.add(coche1);
        coches.add(coche2);

        System.out.println("\n=== Coches con mas de 4 puertas ===");
        for (Coche coche : coches) {
            if (coche.getNumPuertas() > 4) {
                coche.mostrarInfo();
            } else {
                System.out.println("No hay coches con mas de 4 puertas.");
                break;
            }
        }

        // d) Mostrar vehículos de gestión 2025 (año >= 2025)
        System.out.println("\n=== Vehiculos de gestion 2025 ===");
        if (coche2.getAño() >= 2025) {
            coche2.mostrarInfo();
        }
        if (moto1.getAño() >= 2025) {
            moto1.mostrarInfo();
        } else {
            System.out.println("No hay motos de gestion 2025.");
        }
    }
}
