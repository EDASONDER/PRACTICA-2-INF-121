/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio1;

/**
 *
 * @author Usuario
 */
public class Coche extends Vehiculo {
    private int numPuertas;
    private String tipoCombustible;

    // Constructor
    public Coche(String marca, String modelo, int año, double precioBase, 
                 int numPuertas, String tipoCombustible) {
        super(marca, modelo, año, precioBase);  // Llama al constructor del padre
        this.numPuertas = numPuertas;
        this.tipoCombustible = tipoCombustible;
    }

    // Getters y Setters
    public int getNumPuertas() {
        return numPuertas;
    }

    public String getTipoCombustible() {
        return tipoCombustible;
    }

    // Sobrescribe el método mostrarInfo() para añadir atributos propios
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();  // Llama al método del padre
        System.out.println("Numero de puertas: " + numPuertas + 
                         ", Tipo de combustible: " + tipoCombustible);
    }
}