/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio2;

/**
 *
 * @author Usuario
 */
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class EJERCICIO2 {
    public static void main(String[] args) {
        // Crear instancias de Estudiante y Docente
        Estudiante estudiante1 = new Estudiante("1234567", "Ana", "Perez", "70012345", 
                                              LocalDate.of(1995, 5, 10), "RU1001", 
                                              LocalDate.of(2020, 3, 15), 5);
        Estudiante estudiante2 = new Estudiante("7654321", "Luis", "Gomez", "70123456", 
                                              LocalDate.of(2000, 8, 20), "RU1002", 
                                              LocalDate.of(2021, 8, 10), 3);
        Docente docente1 = new Docente("9876543", "Carlos", "Gomez", "71234567", 
                                     LocalDate.of(1980, 11, 25), "NIT2001", 
                                     "Ingeniero", "Sistemas");
        Docente docente2 = new Docente("4567890", "Maria", "Lopez", "72345678", 
                                     LocalDate.of(1975, 4, 5), "NIT2002", 
                                     "Licenciada", "Educacion");

        // b) Mostrar información de las personas
        System.out.println("=== Informacion de Personas ===");
        estudiante1.mostrarInfo();
        System.out.println("-------------------");
        estudiante2.mostrarInfo();
        System.out.println("-------------------");
        docente1.mostrarInfo();
        System.out.println("-------------------");
        docente2.mostrarInfo();

        // c) Mostrar estudiantes mayores de 25 años
        List<Estudiante> estudiantes = new ArrayList<>();
        estudiantes.add(estudiante1);
        estudiantes.add(estudiante2);

        System.out.println("\n=== Estudiantes mayores de 25 anos ===");
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.calcularEdad() > 25) {
                estudiante.mostrarInfo();
            }
        }

        // d) Mostrar docente con profesión "Ingeniero", sexo masculino y mayor de todos
        List<Docente> docentes = new ArrayList<>();
        docentes.add(docente1);
        docentes.add(docente2);

        System.out.println("\n=== Docente Ingeniero, masculino y mayor ===");
        Docente docenteMayor = null;
        int edadMaxima = 0;

        for (Docente docente : docentes) {
            if (docente.getProfesion().equalsIgnoreCase("Ingeniero") && 
                docente.getNombre().equals("Carlos")) { // Asumimos que "Carlos" es masculino
                int edad = docente.calcularEdad();
                if (edad > edadMaxima) {
                    edadMaxima = edad;
                    docenteMayor = docente;
                }
            }
        }

        if (docenteMayor != null) {
            docenteMayor.mostrarInfo();
        } else {
            System.out.println("No se encontró al docente con los criterios especificados.");
        }

        // e) Mostrar estudiantes y docentes con el mismo apellido
        System.out.println("\n=== Personas con el mismo apellido ===");
        for (Estudiante estudiante : estudiantes) {
            for (Docente docente : docentes) {
                if (estudiante.getApellido().equalsIgnoreCase(docente.getApellido())) {
                    System.out.println("Estudiante y Docente con apellido " + estudiante.getApellido() + ":");
                    estudiante.mostrarInfo();
                    docente.mostrarInfo();
                    System.out.println("-------------------");
                }
            }
        }
    }
}