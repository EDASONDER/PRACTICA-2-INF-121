/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio2;

/**
 *
 * @author Usuario
 */
import java.time.LocalDate;
import java.time.Period;

public class Persona {
    private String ci;
    private String nombre;
    private String apellido;
    private String celular;
    private LocalDate fechaNac;

    // Constructor con datos por defecto
    public Persona(String ci, String nombre, String apellido, String celular, LocalDate fechaNac) {
        this.ci = ci;
        this.nombre = nombre;
        this.apellido = apellido;
        this.celular = celular;
        this.fechaNac = fechaNac;
    }

    // Getters y Setters
    public String getCi() {
        return ci;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getCelular() {
        return celular;
    }

    public LocalDate getFechaNac() {
        return fechaNac;
    }

    // Método para calcular la edad
    public int calcularEdad() {
        return Period.between(fechaNac, LocalDate.now()).getYears();
    }

    // Método para mostrar información básica
    public void mostrarInfo() {
        System.out.println("CI: " + ci + ", Nombre: " + nombre + " " + apellido + 
                         ", Celular: " + celular + ", Edad: " + calcularEdad() + " anos");
    }
}