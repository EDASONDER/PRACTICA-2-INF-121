/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio2;

/**
 *
 * @author Usuario
 */
import java.time.LocalDate;
public class Docente extends Persona {
    private String nit;
    private String profesion;
    private String especialidad;

    // Constructor con datos por defecto
    public Docente(String ci, String nombre, String apellido, String celular, LocalDate fechaNac, 
                    String nit, String profesion, String especialidad) {
        super(ci, nombre, apellido, celular, fechaNac);
        this.nit = nit;
        this.profesion = profesion;
        this.especialidad = especialidad;
    }

    // Getters y Setters
    public String getNit() {
        return nit;
    }

    public String getProfesion() {
        return profesion;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    // Sobrescribe el método mostrarInfo()
    @Override
    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("NIT: " + nit + ", Profesion: " + profesion + 
                         ", Especialidad: " + especialidad);
    }
}